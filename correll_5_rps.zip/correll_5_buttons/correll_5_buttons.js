var won = 0,
    lost = 0,
    tied = 0;
var botguess;
var thing = false;

function switchb() {
    if (thing === true) {
        var background = document.getElementById("Background");
        var header = document.getElementById("Header");
        var article1 = document.getElementById("Article1");
        var article2 = document.getElementById("Article2");
        var article3 = document.getElementById("Article3");
        var footer = document.getElementById("Footer");
        
        background.style.backgroundColor = '#FFFF9D';
        header.style.backgroundColor = '#DB316A';
        article1.style.backgroundColor = '#259B9E';
        article2.style.backgroundColor = '#259B9E';
        article3.style.backgroundColor = '#259B9E';
        footer.style.backgroundColor = '#DB316A';
        
        thing = false;
        
    } else {
        var background = document.getElementById("Background");
        var header = document.getElementById("Header");
        var article1 = document.getElementById("Article1");
        var article2 = document.getElementById("Article2");
        var article3 = document.getElementById("Article3");
        var footer = document.getElementById("Footer");
    
        background.style.backgroundColor = '#BCFFB8';
        header.style.backgroundColor = '#4749A9';
        article1.style.backgroundColor = '#54B24C';
        article2.style.backgroundColor = '#54B24C';
        article3.style.backgroundColor = '#54B24C';
        footer.style.backgroundColor = '#4749A9';
        
        thing = true;
    }
}

function rockb() {
    var bot = Math.floor((Math.random() * 3) + 1);
    
    if (bot == 1) {
        botguess = "Rock";
    } else if (bot == 2) {
        botguess = "Paper";
    } else {
        botguess = "Scissors";
    }
    
    document.getElementById("botguess").innerHTML="<br>The computer picked " + botguess + "!";
    
    if (botguess == "Rock") {
        document.getElementById("result").innerHTML="You are tied this round!";
        tied += 1;
    } else if (botguess == "Paper") {
        document.getElementById("result").innerHTML="You lost this round!";
        lost += 1;
    } else {
        document.getElementById("result").innerHTML="You won this round!";
        won += 1;
    }
        document.getElementById("wlt").innerHTML="<br>Won = " + won + "<br>Lost = " + lost + "<br>Tied = " + tied;
}

function paperb() {
    var bot = Math.floor((Math.random() * 3) + 1);
    
    if (bot == 1) {
        botguess = "Rock";
    } else if (bot == 2) {
        botguess = "Paper";
    } else {
        botguess = "Scissors";
    }
    
    document.getElementById("botguess").innerHTML="<br>The computer picked " + botguess + "!";
    
    if (botguess == "Rock") {
        document.getElementById("result").innerHTML="You won this round!";
        won += 1;
    } else if (botguess == "Paper") {
        document.getElementById("result").innerHTML="You are tied this round!"; 
        tied += 1;
    } else {
        document.getElementById("result").innerHTML="You lost this round!";
        lost += 1;
    }
        document.getElementById("wlt").innerHTML="<br>Won = " + won + "<br>Lost = " + lost + "<br>Tied = " + tied;
}

function scissorsb() {
    var bot = Math.floor((Math.random() * 3) + 1);
    
    if (bot == 1) {
        botguess = "Rock";
    } else if (bot == 2) {
        botguess = "Paper";
    } else {
        botguess = "Scissors";
    }
    
    document.getElementById("botguess").innerHTML="<br>The computer picked " + botguess + "!";
    
    if (botguess == "Rock") {
        document.getElementById("result").innerHTML="You lost this round!";
        lost += 1;
    } else if (botguess == "Paper") {
        document.getElementById("result").innerHTML="You won this round!";   
        won += 1;
    } else {
        document.getElementById("result").innerHTML="You are tied this round!";
        tied += 1;
    }
        document.getElementById("wlt").innerHTML="<br>Won = " + won + "<br>Lost = " + lost + "<br>Tied = " + tied;
}

function replayb() {
    won = 0;
    lost = 0;
    tied = 0;
    
    document.getElementById("wlt").innerHTML="<br>Won = " + won + "<br>Lost = " + lost + "<br>Tied = " + tied;
}