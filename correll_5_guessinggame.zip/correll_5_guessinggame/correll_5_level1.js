var num = prompt("Pick a number!");
var random = Math.floor((Math.random() * 100) + 1);
var guesses = 5;
document.write(random);

while ((guesses > 0) && (random != num)) {
    if (num > random) {
        num = prompt("Too high!");
        guesses--;
        alert(guesses + " guesses left");
} else {
        num = prompt("Too low!");
        guesses--;
        alert(guesses + " guesses left");
}
}

if (num == random) {
    document.write("<br>You win!")
} else {
    document.write("<br>I'm not sure if you are educated")
}
    document.write("<br>The number was " + random);