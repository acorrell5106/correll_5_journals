alert('Meow!')
window.alert('this is a window')
window.confirm('shall we continue')
var x = 42;
if (r == true) {
x = "You pressed OK!";
} else {
x = "You pressed Cancel!"
}
document.write(x);
