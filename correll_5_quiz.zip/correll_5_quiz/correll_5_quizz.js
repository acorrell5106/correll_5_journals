var q1 = prompt("Question 1:", "What is 17*22?");
    //374
var q2 = prompt("Question 2:", "What is 333/111?");
    //3
var q3 = prompt("Question 3:", "What is 74+26?");
    //100
var q4 = prompt("Question 4:", "What is 55*79?");
    //4345
var q5 = prompt("Question 5:", "What is 18/4.5?");
    //4
var q6 = prompt("Question 6:", "What is 23-14?");
    //9
var q7 = prompt("Question 7:", "What is 27+73?");
    //100
var q8 = prompt("Question 8:", "What is 36/9?");
    //4
var q9 = prompt("Question 9:", "What is 16*8?");
    //128
var q10 = prompt("Question 10:", "What is 111-11?");
    //100
    var points = 10;
    
    if (q1 == 374) {
    } else {
         points--;
    }

    if (q2 !== 3) {
    
    } else {
         points--;
    }

    if (q3 !== 100) {
    
    } else {
         points--;
    }

    if (q4 !== 4345) {
    
    } else {
         points--;
    }

    if (q5 !== 4) {
    } else {
         points--;
    }

    if (q6 !== 9) {
    } else {
         points--;
    }

    if (q7 !== 100) {
    } else {
         points--;
    }

    if (q8 !== 4) {
    } else {
         points--;
    }

    if (q9 !== 128) {
    } else {
         points--;
    }

    if (q10 !== 100) {
    } else {
         points--;
    }

document.write("You got " + points + " questions right!");