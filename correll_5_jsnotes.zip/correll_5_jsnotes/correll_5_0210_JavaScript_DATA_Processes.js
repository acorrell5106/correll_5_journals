document.getElementById("p2").style.color = "red";

document.write("This is how we math in JavaScript: <br>");
var k = prompt("Pick a number");
var r = prompt("Pick another number");
var num1 = parseInt(k);
var num2 = parseInt(r);
var d = num1 + num2;
document.write("k is " + k + ", r is " + r + ", and d is k + r and it's " + d + "<br>");
document.write("Multiplication: ");
document.write(k * r + "<br>");
document.write("Division: ");
document.write(d / k + "<br>");
document.write("Addition: ");
document.write(num1 + num2 + "<br>");
document.write("Subtraction: ");
document.write(d - r + "<br>");

document.write("This is num1: " + num1 + "<br>");
document.write("This is num2: " + num2 + "<br>");
num1++;
document.write("This is num1: " + num1++ + "<br>");
num2++;
document.write("This is num2: " + num2++ + "<br>");
num1 = 50;
num1 += 5;
document.write(num1 + "<br>");
num1 -= 5;
document.write(num1 + "<br>");
num1 /= 5;
document.write(num1 + "<br>");

if (k == r) {
    document.write("<br>k and r are the same");
} else if (k < r){
    document.write("<br>k is less than r");
} else if (r < k) {
    document.write("<br>k is greater than r");
} else {
    document.write("<br>k and r are NOT the same, and this should never happen");
}